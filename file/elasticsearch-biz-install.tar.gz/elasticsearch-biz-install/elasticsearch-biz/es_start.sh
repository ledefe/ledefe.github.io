#!/bin/bash
_pid=`ps -ef|grep elasticsearch-biz|grep -v 'grep'|grep -e "su" |awk '{print $2}'`
if [ ! -z $_pid ] ;then
 kill $_pid
fi
export JAVA_HOME=/usr/local/java
su es  /home/es/elasticsearch-biz/bin/elasticsearch >/dev/null 2>&1 &
