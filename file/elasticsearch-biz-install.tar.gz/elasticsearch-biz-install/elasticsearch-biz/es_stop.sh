#!/bin/bash
_pid=`ps -ef|grep elasticsearch-biz|grep -v 'grep'|grep -e "su" |awk '{print $2}'`
if [ ! -z $_pid ] ;then
 kill $_pid
fi
