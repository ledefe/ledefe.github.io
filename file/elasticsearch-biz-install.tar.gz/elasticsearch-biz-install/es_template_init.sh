#!/bin/bash
#save one week data
curl -XPUT "http://127.0.0.1:9200/_template/bidata" -d '
{
    "order": 0,
    "template": "bi_*",
    "settings": {
        "index.codec": "best_compression",
        "index": {
            "analysis": {
                "analyzer": {
                    "std_cn_en_analyzer": {
                        "type": "standard",
                        "max_token_length": 1,
                        "filter": [
                            "lowercase"
                        ]
                    }
                }
            },
            "number_of_shards": "2",
            "number_of_replicas": "1"
        }
    },
    "mappings": {
        "bi_audit": {
            "properties": {
                "id": {
                    "type": "text"
                },
                "operation": {
                    "type": "text"
                },
                "ret": {
                    "type": "integer"
                },
                "detail": {
                    "type": "text"
                },
                "time": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                }
            }
        },
        "bi_mcu_call": {
            "properties": {
                "callid": {
                    "type": "keyword"
                },
                "confid": {
                    "type": "long"
                },
                "uid": {
                    "type": "text"
                },
                "codec": {
                    "type": "text"
                },
                "samplerate": {
                    "type": "long"
                },
                "bandwidth": {
                    "type": "long"
                },
                "bitrate": {
                    "type": "long"
                },
                "lossrate": {
                    "type": "long"
                },
                "packetlost": {
                    "type": "long"
                },
                "jitter": {
                    "type": "long"
                },
                "rtt": {
                    "type": "long"
                },
                "width": {
                    "type": "long"
                },
                "height": {
                    "type": "long"
                },
                "fr": {
                    "type": "long"
                },
                "evtbr": {
                    "type": "long"
                },
                "netstat": {
                    "type": "text"
                },
                "sesstype": {
                    "type": "keyword"
                },
                "direction": {
                    "type": "keyword"
                },
                "time": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                }
            }
        },
        "bi_terminal_register": {
            "properties": {
                "termType": {
                    "type": "keyword"
                },
                "termVer": {
                    "type": "keyword"
                },
                "termAccount": {
                    "type": "text"
                },
                "envName": {
                    "type": "text"
                },
                "offlineTime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "regTime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                }
            }
        },"bi_terminal_call": {
            "properties": {
                "formTermPort": {
                    "type": "keyword"
                },
                "toTermPort": {
                    "type": "keyword"
                },
                "fromAccount": {
                    "type": "text"
                },
                "toAccount": {
                    "type": "text"
                },
                "startTime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "endTime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                }
            }
        },"bi_meeting": {
            "properties": {
                "envName": {
                    "type": "text"
                },
                "actualNum": {
                    "type": "long"
                },
                "startTime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "endTime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                }
            }
        },
        "_default_": {
            "dynamic": "true",
            "_source": {
                "enabled": true
            },
            "dynamic_templates": [
                {
                    "strings": {
                        "match_mapping_type": "string",
                        "mapping": {
                            "type": "keyword"
                        }
                    }
                }
            ],
            "properties": {
                "@timestamp": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "uptime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "biz": {
                    "type": "keyword"
                },
                "source": {
                    "type": "keyword"
                },
                "ip": {
                    "search_analyzer": "std_cn_en_analyzer",
                    "analyzer": "std_cn_en_analyzer",
                    "type": "text"
                }
            },
            "_all": {
                "enabled": false
            }
        }
    },
    "aliases": {}
}
  '