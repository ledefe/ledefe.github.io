#!/bin/bash
#save one week data
curl -XPUT "http://127.0.0.1:9200/_template/bi_audit" -d '
{
    "order": 0,
    "template": "bi_audit-*",
    "settings": {
        "index.codec": "best_compression",
        "index": {
            "analysis": {
                "analyzer": {
                    "std_cn_en_analyzer": {
                        "type": "standard",
                        "max_token_length": 1,
                        "filter": [
                            "lowercase"
                        ]
                    }
                }
            },
            "number_of_shards": "2",
            "number_of_replicas": "0"
        }
    },
    "mappings": {
        "bi_audit": {
            "properties": {
                "id": {
                    "type": "text"
                },
                "operation": {
                    "type": "text"
                },
                "ret": {
                    "type": "integer"
                },
                "detail": {
                    "type": "text"
                },
                "time": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                }
            }
        },
        "_default_": {
            "dynamic": "true",
            "_source": {
                "enabled": true
            },
            "dynamic_templates": [
                {
                    "strings": {
                        "match_mapping_type": "string",
                        "mapping": {
                            "type": "keyword"
                        }
                    }
                }
            ],
            "properties": {
                "@timestamp": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "uptime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "biz": {
                    "type": "keyword"
                },
                "source": {
                    "type": "keyword"
                },
                "ip": {
                    "search_analyzer": "std_cn_en_analyzer",
                    "analyzer": "std_cn_en_analyzer",
                    "type": "text"
                }
            },
            "_all": {
                "enabled": false
            }
        }
    },
    "aliases": {}
}'

curl -XPUT "http://127.0.0.1:9200/_template/bi_login" -d '
{
    "order": 0,
    "template": "bi_login-*",
    "settings": {
        "index.codec": "best_compression",
        "index": {
            "analysis": {
                "analyzer": {
                    "std_cn_en_analyzer": {
                        "type": "standard",
                        "max_token_length": 1,
                        "filter": [
                            "lowercase"
                        ]
                    }
                }
            },
            "number_of_shards": "2",
            "number_of_replicas": "0"
        }
    },
    "mappings": {
    	"bi_login":{
    		"properties": {
    			"password": {
                    "type": "text"
                },"result": {
                    "type": "text"
                },"username": {
                    "type": "text"
                },"userAgent": {
                    "type": "text"
                },"url": {
                    "type": "text"
                },"loginTime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                }
    		}
    	},
        "_default_": {
            "dynamic": "true",
            "_source": {
                "enabled": true
            },
            "dynamic_templates": [
                {
                    "strings": {
                        "match_mapping_type": "string",
                        "mapping": {
                            "type": "keyword"
                        }
                    }
                }
            ],
            "properties": {
                "@timestamp": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "uptime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "biz": {
                    "type": "keyword"
                },
                "source": {
                    "type": "keyword"
                },
                "ip": {
                    "search_analyzer": "std_cn_en_analyzer",
                    "analyzer": "std_cn_en_analyzer",
                    "type": "text"
                }
            },
            "_all": {
                "enabled": false
            }
        }
    },
    "aliases": {}
}'


curl -XPUT "http://127.0.0.1:9200/_template/bi_mcu_call" -d '
{
    "order": 0,
    "template": "bi_mcu_call-*",
    "settings": {
        "index.codec": "best_compression",
        "index": {
            "analysis": {
                "analyzer": {
                    "std_cn_en_analyzer": {
                        "type": "standard",
                        "max_token_length": 1,
                        "filter": [
                            "lowercase"
                        ]
                    }
                }
            },
            "number_of_shards": "2",
            "number_of_replicas": "1"
        }
    },
    "mappings": {
        "bi_mcu_call": {
            "properties": {
                "callid": {
                    "type": "keyword"
                },
                "confid": {
                    "type": "long"
                },
                "uid": {
                    "type": "text"
                },
                "codec": {
                    "type": "text"
                },
                "samplerate": {
                    "type": "long"
                },
                "bandwidth": {
                    "type": "long"
                },
                "bitrate": {
                    "type": "long"
                },
                "lossrate": {
                    "type": "long"
                },
                "packetlost": {
                    "type": "long"
                },
                "jitter": {
                    "type": "long"
                },
                "rtt": {
                    "type": "long"
                },
                "width": {
                    "type": "long"
                },
                "height": {
                    "type": "long"
                },
                "fr": {
                    "type": "long"
                },
                "evtbr": {
                    "type": "long"
                },
                "netstat": {
                    "type": "text"
                },
                "sesstype": {
                    "type": "keyword"
                },
                "direction": {
                    "type": "keyword"
                },
                "time": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                }
            }
        },
        "_default_": {
            "dynamic": "true",
            "_source": {
                "enabled": true
            },
            "dynamic_templates": [
                {
                    "strings": {
                        "match_mapping_type": "string",
                        "mapping": {
                            "type": "keyword"
                        }
                    }
                }
            ],
            "properties": {
                "@timestamp": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "uptime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "biz": {
                    "type": "keyword"
                },
                "source": {
                    "type": "keyword"
                },
                "ip": {
                    "search_analyzer": "std_cn_en_analyzer",
                    "analyzer": "std_cn_en_analyzer",
                    "type": "text"
                }
            },
            "_all": {
                "enabled": false
            }
        }
    },
    "aliases": {}
}
'

curl -XPUT "http://127.0.0.1:9200/_template/bi_meeting" -d '
{
    "order": 0,
    "template": "bi_meeting-*",
    "settings": {
        "index.codec": "best_compression",
        "index": {
            "analysis": {
                "analyzer": {
                    "std_cn_en_analyzer": {
                        "type": "standard",
                        "max_token_length": 1,
                        "filter": [
                            "lowercase"
                        ]
                    }
                }
            },
            "number_of_shards": "2",
            "number_of_replicas": "1"
        }
    },
    "mappings": {
        "bi_meeting": {
            "properties": {
                "envName": {
                    "type": "text"
                },
                "actualNum": {
                    "type": "long"
                },
                "startTime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "endTime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                }
            }
        },
        "_default_": {
            "dynamic": "true",
            "_source": {
                "enabled": true
            },
            "dynamic_templates": [
                {
                    "strings": {
                        "match_mapping_type": "string",
                        "mapping": {
                            "type": "keyword"
                        }
                    }
                }
            ],
            "properties": {
                "@timestamp": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "uptime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "biz": {
                    "type": "keyword"
                },
                "source": {
                    "type": "keyword"
                },
                "ip": {
                    "search_analyzer": "std_cn_en_analyzer",
                    "analyzer": "std_cn_en_analyzer",
                    "type": "text"
                }
            },
            "_all": {
                "enabled": false
            }
        }
    },
    "aliases": {}
}
'
curl -XPUT "http://127.0.0.1:9200/_template/bi_term_call" -d '
{
    "order": 0,
    "template": "bi_term_call-*",
    "settings": {
        "index.codec": "best_compression",
        "index": {
            "analysis": {
                "analyzer": {
                    "std_cn_en_analyzer": {
                        "type": "standard",
                        "max_token_length": 1,
                        "filter": [
                            "lowercase"
                        ]
                    }
                }
            },
            "number_of_shards": "2",
            "number_of_replicas": "1"
        }
    },
    "mappings": {
        "bi_term_call": {
            "properties": {
                "version": {
                    "type": "integer"
                },
                "callType": {
                    "type": "keyword"
                },
                "conferenceEntity": {
                    "type": "text"
                },
                "conferenceUserEntity": {
                    "type": "text"
                },
                "callId": {
                    "type": "keyword"
                },
                "fromTag": {
                    "type": "keyword"
                },
                "toTag": {
                    "type": "keyword"
                },
                "callerHostname": {
                    "type": "keyword"
                },
                "callerUid": {
                    "type": "keyword"
                },
                "callerNumber": {
                    "type": "keyword"
                },
                "callerDomain": {
                    "type": "keyword"
                },
                "callerAuthname": {
                    "type": "keyword"
                },
                "callerRealm": {
                    "type": "keyword"
                },
                "callerDisplayName": {
                    "type": "text"
                },
                "callerGruu": {
                    "type": "text"
                },
                "callerUserAgent": {
                    "type": "text"
                },
                "calleeHostname": {
                    "type": "keyword"
                },
                "calleeUid": {
                    "type": "keyword"
                },
                "calleeNumber": {
                    "type": "keyword"
                },
                "calleeDomain": {
                    "type": "keyword"
                },
                "calleeAuthname": {
                    "type": "keyword"
                },
                "calleeRealm": {
                    "type": "keyword"
                },
                "calleeDisplayName": {
                    "type": "text"
                },
                "calleeGruu": {
                    "type": "text"
                },
                "calleeUserAgent": {
                    "type": "text"
                },
                "startTime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "answerTime": {
                    "type": "long"
                },
                "endTime": {
                      "format": "epoch_millis||strict_date_optional_time",
                      "type": "date"
                },
                "duration": {
                    "type": "integer"
                },
                "billsec": {
                    "type": "integer"
                }
            }
        },
        "_default_": {
            "dynamic": "true",
            "_source": {
                "enabled": true
            },
            "dynamic_templates": [
                {
                    "strings": {
                        "match_mapping_type": "string",
                        "mapping": {
                            "type": "keyword"
                        }
                    }
                }
            ],
            "properties": {
                "@timestamp": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "uptime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "biz": {
                    "type": "keyword"
                },
                "source": {
                    "type": "keyword"
                },
                "ip": {
                    "search_analyzer": "std_cn_en_analyzer",
                    "analyzer": "std_cn_en_analyzer",
                    "type": "text"
                }
            },
            "_all": {
                "enabled": false
            }
        }
    },
    "aliases": {}
}
'
curl -XPUT "http://127.0.0.1:9200/_template/bi_term_register" -d '
{
    "order": 0,
    "template": "bi_term_register-*",
    "settings": {
        "index.codec": "best_compression",
        "index": {
            "analysis": {
                "analyzer": {
                    "std_cn_en_analyzer": {
                        "type": "standard",
                        "max_token_length": 1,
                        "filter": [
                            "lowercase"
                        ]
                    }
                }
            },
            "number_of_shards": "2",
            "number_of_replicas": "1"
        }
    },
    "mappings": {
        "bi_term_register": {
            "properties": {
                "termType": {
                    "type": "keyword"
                },
                "termVer": {
                    "type": "keyword"
                },
                "termAccount": {
                    "type": "text"
                },
                "envName": {
                    "type": "text"
                },
                "offlineTime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "regTime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                }
            }
        },
        "_default_": {
            "dynamic": "true",
            "_source": {
                "enabled": true
            },
            "dynamic_templates": [
                {
                    "strings": {
                        "match_mapping_type": "string",
                        "mapping": {
                            "type": "keyword"
                        }
                    }
                }
            ],
            "properties": {
                "@timestamp": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "uptime": {
                    "format": "epoch_millis||strict_date_optional_time",
                    "type": "date"
                },
                "biz": {
                    "type": "keyword"
                },
                "source": {
                    "type": "keyword"
                },
                "ip": {
                    "search_analyzer": "std_cn_en_analyzer",
                    "analyzer": "std_cn_en_analyzer",
                    "type": "text"
                }
            },
            "_all": {
                "enabled": false
            }
        }
    },
    "aliases": {}
}
'