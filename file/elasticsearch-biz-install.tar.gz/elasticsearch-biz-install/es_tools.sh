masterNodes=1;
while getopts "n:h:m:d:e:" opt; do
 case $opt in
  n)
   nodeName=$OPTARG;
   echo "the nodeName  is $nodeName";;
  h)
   hosts=$OPTARG;
   echo "the hosts  is $hosts";; 
  m) 
   master=$OPTARG;;
  d)
   data=$OPTARG;;
  e)
   masterNodes=$OPTARG;;
  \?)
   echo "Invalid option: -$OPTARG";
   exit -1;;
esac
done

if [ ! -n "$nodeName" ]; then
  echo "-n must to set for nodeName,exaple '-n data-01'"
exit -1
fi

if [ ! -n "$hosts" ]; then
  echo "-n must to set for hosts,exaple '-h 127.0.0.1:9300,127.0.0.2:9300'"
exit -1
fi

if [ "$master" == "true" -o  "$master" == "false" ]; then
  echo "master validate ok"
else
 echo "-m must to set for master node exaple '-m true|false'"
 exit -1
fi

if [  "$data" == "true" -o  "$data" == "false" ]; then
  echo "data validate ok"
else 
  echo "-d must to set for data node,exaple '-d true|false'"
  exit -1
fi

tar -zxvf ./elasticsearch-biz.tar.gz -C /home/es

if [[ $masterNodes != *[!0-9]* ]]; then
    echo "'$masterNodes' is strictly numeric"
else
    echo "-e  must a number to set"
    exit -1 
fi


arr=$(echo $hosts|tr "," "\n")

nh="";
for x in $arr; do
 nh=\"$x\",$nh
done


len="$nh"|wc -L
nh=${nh:0:(len-1)}

echo $nh
sed -i "s#^node.name:.*#node.name: $nodeName#g" /home/es/elasticsearch-biz/config/elasticsearch.yml
sed -i "s#^discovery.zen.ping.unicast.hosts:.*#discovery.zen.ping.unicast.hosts: [${nh}]#g" /home/es/elasticsearch-biz/config/elasticsearch.yml

if [ "$data" == "true" ]; then
 sed -i "s#^node.data:.*#node.data: true#g" /home/es/elasticsearch-biz/config/elasticsearch.yml
else
 sed -i "s#^node.data:.*#node.data: false#g" /home/es/elasticsearch-biz/config/elasticsearch.yml
 sed -i "s#^-Xms4g.*#-Xms1g#g" /home/es/elasticsearch-biz/config/jvm.options
 sed -i "s#^-Xmx4g.*#-Xmx1g#g" /home/es/elasticsearch-biz/config/jvm.options
fi

if [ "$master" == "true" ]; then
 sed -i "s#^node.master:.*#node.master: true#g" /home/es/elasticsearch-biz/config/elasticsearch.yml
else
 sed -i "s#^node.master:.*#node.master: false#g" /home/es/elasticsearch-biz/config/elasticsearch.yml
fi

sed -i "s#^discovery.zen.minimum_master_nodes:.*#discovery.zen.minimum_master_nodes: ${masterNodes}#g" /home/es/elasticsearch-biz/config/elasticsearch.yml

result=$(grep "/home/es/elasticsearch-biz/es_start.sh" /etc/rc.d/rc.local)
if echo $result |grep -q "/home/es/elasticsearch-biz/es_start.sh"; then
	echo "ignore auto setup set"
else
	echo '/home/es/elasticsearch-biz/es_start.sh'>>/etc/rc.d/rc.local
fi
chmod +x /etc/rc.d/rc.local
