masterNodes=1;
esPort=9200;
installDir=/home/es
jvmSize=1
while getopts "n:h:m:d:e:p:j:" opt; do
 case $opt in
  n)
   nodeName=$OPTARG;
   echo "the nodeName  is $nodeName";;
  h)
   hosts=$OPTARG;
   echo "the hosts  is $hosts";; 
  m) 
   master=$OPTARG;;
  d)
   data=$OPTARG;;
  e)
   masterNodes=$OPTARG;;
  p)
   esPort=$OPTARG;;
  j)
   jvmSize=$OPTARG;;
  \?)
   echo "Invalid option: -$OPTARG";
   exit -1;;
esac
done

if [ ! -n "$nodeName" ]; then
  echo "-n must to set for nodeName,exaple '-n data-01'"
exit -1
fi

if [ ! -n "$hosts" ]; then
  echo "-n must to set for hosts,exaple '-h 127.0.0.1:9300,127.0.0.2:9300'"
exit -1
fi

if [ "$master" == "true" -o  "$master" == "false" ]; then
  echo "master validate ok"
else
 echo "-m must to set for master node exaple '-m true|false'"
 exit -1
fi

if [  "$data" == "true" -o  "$data" == "false" ]; then
  echo "data validate ok"
else 
  echo "-d must to set for data node,exaple '-d true|false'"
  exit -1
fi

esDir=${installDir}/elasticsearch-biz_${nodeName}
if [ ! -d "${esDir}" ];then
 cp -rf elasticsearch-biz ${esDir}
else 
 cp -rf elasticsearch-biz/* ${esDir}
fi

if [[ $masterNodes != *[!0-9]* ]]; then
    echo 'minimum_master_nodes value is ' ${masterNodes}
else
    echo "-e  must a number to set for minimum_master_nodes"
    exit -1 
fi


if [[ $esPort != *[!0-9]* ]]; then
    echo "this node es http.port is  '$esPort'"
    echo "this node es transport.tcp.port is  '$(($esPort+1))'"
else
    echo "-p  must a number to set for es port"
    exit -1
fi




if [[ ${jvmSize} != *[!0-9]* ]]; then
    echo "Xms Xmx be set to: ${jvmSize}g"
else
     jvmSize=1
    echo "Xms Xmx be set to: ${jvmSize}g"
fi


arr=$(echo $hosts|tr "," "\n")

echo 'unicast hosts' $arr
num=0;
nh="";
for x in $arr; do
 nh=\"$x\",$nh
 num=$(($num+1))
done


## masterNodes=$(($num/2+1))
## echo 'minimum_master_nodes value is ' ${masterNodes}

len="$nh"|wc -L
nh=${nh:0:(len-1)}

ymlFile=${esDir}/config/elasticsearch.yml
jvmFile=${esDir}/config/jvm.options
scriptStartFile=${esDir}/es_start.sh
scriptStopFile=${esDir}/es_stop.sh
sed -i "s#^node.name:.*#node.name: ${nodeName}#g" ${ymlFile}
sed -i "s#^discovery.zen.ping.unicast.hosts:.*#discovery.zen.ping.unicast.hosts: [${nh}]#g" ${ymlFile}

if [ "${data}" == "true" ]; then
 sed -i "s#^node.data:.*#node.data: true#g" ${ymlFile}
else
 sed -i "s#^node.data:.*#node.data: false#g" ${ymlFile}
fi

sed -i "s#^-Xmx.*#-Xmx${jvmSize}g#g" ${jvmFile}
sed -i "s#^-Xms.*#-Xms${jvmSize}g#g" ${jvmFile}

if [ "${master}" == "true" ]; then
 sed -i "s#^node.master:.*#node.master: true#g" ${ymlFile}
else
 sed -i "s#^node.master:.*#node.master: false#g" ${ymlFile}
fi

sed -i "s#^discovery.zen.minimum_master_nodes:.*#discovery.zen.minimum_master_nodes: ${masterNodes}#g" ${ymlFile}

sed -i "s#^http.port:.*#http.port: ${esPort}#g" ${ymlFile}
sed -i "s#^transport.tcp.port:.*#transport.tcp.port: $(($esPort+1))#g" ${ymlFile}

sed -i "s#^path.data:.*#path.data: /data/elasticsearch/${nodeName}/data#g" ${ymlFile}
sed -i "s#^path.logs:.*#path.logs: /data/elasticsearch/${nodeName}/logs#g" ${ymlFile}


echo "path.data: /data/elasticsearch/${nodeName}/data"
echo "path.logs: /data/elasticsearch/${nodeName}/logs"

## start script
echo "#!/bin/bash" > ${scriptStartFile}
echo "_pid=\`ps -ef|grep ${esDir}|grep -v 'grep'|grep -e \"su\" |awk '{print \$2}'\`">>${scriptStartFile}
echo "if [ ! -z \$_pid ] ;then">>${scriptStartFile}
echo " kill \$_pid">>${scriptStartFile}
echo "fi">>${scriptStartFile}
echo "export JAVA_HOME=/usr/local/java">>${scriptStartFile}
echo "su es  ${esDir}/bin/elasticsearch >/dev/null 2>&1 &">>${scriptStartFile}
## stop script
echo "#!/bin/bash">${scriptStopFile}
echo "_pid=\`ps -ef|grep ${esDir}|grep -v 'grep'|grep -e \"su\" |awk '{print \$2}'\`">>${scriptStopFile}
echo "if [ ! -z \$_pid ] ;then">>${scriptStopFile}
echo " kill \$_pid">>${scriptStopFile}
echo "fi">>${scriptStopFile}


result=$(grep "${scriptStartFile}" /etc/rc.d/rc.local)
if echo $result |grep -q "${scriptStartFile}"; then
	echo "ignore auto setup set"
else
	echo '${scriptStartFile}'>>/etc/rc.d/rc.local
fi
sudo chown -R es ${installDir}
chmod +x /etc/rc.d/rc.local
