mkdir -p /data/elasticsearch
groupadd es
useradd es -g es -p 'es123!@#'
chown  es /home/es -R
chown  es /data/elasticsearch -R

#init sys setting
sysDir=/etc/sysctl.conf
result=`grep "fs.file-max=" $sysDir`
if echo $result |grep -q "fs.file-max="; then  
  sed -i "s#^fs.file-max=.*#fs.file-max=655350#g" $sysDir
else  
  echo 'fs.file-max=655350'>>$sysDir
fi
result=`grep "vm.max_map_count=" $sysDir`
if echo $result |grep -q "vm.max_map_count="; then 
  sed -i "s#^vm.max_map_count=.*#vm.max_map_count=262144#g" $sysDir
else  
  echo 'vm.max_map_count=262144'>>$sysDir
fi
limitDir=/etc/security/limits.conf
result=`grep "soft nproc" $limitDir`
if echo $result |grep -q "soft nproc"; then
  sed -i "s#^\* soft nproc.*#\* soft nproc 65536#g" $limitDir
else
  echo '* soft nproc 65536'>>$limitDir
fi
result=`grep "hard nproc" $limitDir`
if echo $result |grep -q "hard nproc"; then
  sed -i "s#^\* hard nproc.*#\* hard nproc 65536#g" $limitDir
else
  echo '* hard nproc 65536'>>$limitDir
fi

result=`grep "soft nofile" $limitDir`
if echo $result |grep -q "soft nofile"; then
  sed -i "s#^\* soft nofile.*#\* soft nofile 65536#g" $limitDir
else
  echo '* soft nofile 65536'>>$limitDir
fi

result=`grep "hard nofile" $limitDir`
if echo $result |grep -q "hard nofile"; then
  sed -i "s#^\* hard nofile.*#\* hard nofile 65536#g" $limitDir
else
  echo '* hard nofile 65536'>>$limitDir
fi

cat $sysDir
cat $limitDir

sysctl -p /etc/sysctl.conf